import random
from pomocne import PomocneFunkcije

class I1:

    def generate_solution(gradovi, solution_heur):
            
        solution = []
        
        slucajniIndeks = random.randint(0, len(gradovi)-1)
        solution.append(gradovi[slucajniIndeks])
        gradovi.pop(slucajniIndeks)
        
        slucajniIndeks = random.randint(0, len(gradovi)-1)
        solution.append(gradovi[slucajniIndeks])
        gradovi.pop(slucajniIndeks)

        br = 1
        
        while br < solution_heur:
            
            min_p_d = 100000
            min_p_i = -1
            min_p_g = -1
            for i in range(len(solution)):
                for j in range(len(gradovi)):
                    d = PomocneFunkcije.udaljenost(solution[i][1], gradovi[j][1], solution[i][2], gradovi[j][2]) + PomocneFunkcije.udaljenost(solution[i-1][1], gradovi[j][1], solution[i-1][2], gradovi[j][2])
                    if d < min_p_d:
                        min_p_d = d
                        min_p_i = i
                        min_p_g = j
            solution.insert(min_p_i, gradovi[min_p_g])
            gradovi.pop(min_p_g)
            br += 1

        while br < len(gradovi):
            slucajniIndeks = random.randint(0, len(gradovi)-1)
            solution.append(gradovi[slucajniIndeks])
            gradovi.pop(slucajniIndeks)
            br += 1
        return solution