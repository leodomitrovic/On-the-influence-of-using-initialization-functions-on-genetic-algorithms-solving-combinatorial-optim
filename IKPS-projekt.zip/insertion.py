import random
from pomocne import PomocneFunkcije

class Insertion:
    
    def generate_solution(gradovi, solution_heur):
    
        gradovi_copy = gradovi[:]
        solution = []

        slucajniIndeks = random.randint(0, len(gradovi_copy)-1)
        solution.append(gradovi_copy[slucajniIndeks])
        gradovi_copy.pop(slucajniIndeks)
        
        slucajniIndeks = random.randint(0, len(gradovi_copy)-1)
        solution.append(gradovi_copy[slucajniIndeks])
        gradovi_copy.pop(slucajniIndeks)

        br = 2
        while br < solution_heur:
            
            min_g_d = 10000000
            min_g = []
            min_i = 0
            for j in range(len(solution)):
                tmp = solution[j]
                for i in range(len(gradovi_copy)):
                    d = PomocneFunkcije.udaljenost(gradovi_copy[i][1], tmp[1], gradovi_copy[i][2], tmp[2])
                    if d < min_g_d:
                        min_g_d = d
                        min_g = gradovi_copy[i]
                        min_i = i
            
            min_p_d = 10000000
            min_p_i = -1
            for i in range(len(solution)):
                d = PomocneFunkcije.udaljenost(solution[i][1], min_g[1], solution[i][2], min_g[2]) + PomocneFunkcije.udaljenost(solution[i-1][1], min_g[1], solution[i-1][2], min_g[2])
                if d < min_p_d:
                    min_p_d = d
                    min_p_i = i
            solution.insert(min_p_i, min_g)
            gradovi_copy.pop(min_i)
            br += 1
        
        while len(gradovi_copy) > 0:
            slucajniIndeks = random.randint(0, len(gradovi_copy) - 1)
            solution.append(gradovi_copy[slucajniIndeks])
            gradovi_copy.pop(slucajniIndeks)
        return solution
