from nn import NearestNeighbour
from insertion import Insertion
from i1 import I1
from pomocne import PomocneFunkcije
from gradovi import Gradovi
import numpy as np
from tabulate import tabulate
import time
import ray

# TODO: friedman's test, kod uspoređivanja različitih genetskih algoritama usporediti grad po grad, znači usporediti  prosjek od rješenje[heur=0,rand,grad] sa rješenje[heur=1,rand,grad]

# provjeriti je li u znanstvenom radu pod "time" (engl.) izračunato kao "vrijeme od početka pa do kraja računanja svih 50 eksperimenata za specifičnu heuristiku, randomness i grad" ili average ili median

gradovi = Gradovi.gradovi
imena_gradova = Gradovi.imena_gradova
imena_heuristika = ["Nearest Neighbour", "Insertion", "Solomon I1"]
population_size = 48
broj_eksperimenata = 10 # potrebno za pravi eksperiment staviti na 50, zbog bržeg izračuna sada je 2

heuristike = [NearestNeighbour, Insertion, I1]
randomnesses = [1, 0.5, 0.1, 0]

# rjesenja = np.load('data.npy')
# vremena = np.load('times.npy')

rjesenja = np.zeros((len(heuristike), len(randomnesses), len(gradovi), broj_eksperimenata))
vremena = np.zeros((len(heuristike), len(randomnesses), len(gradovi), broj_eksperimenata))

average_fitness_arr = np.zeros((len(heuristike), len(randomnesses), len(gradovi)), dtype=float)
stdev_arr = np.zeros((len(heuristike), len(randomnesses), len(gradovi)), dtype=float)
average_times = np.zeros((len(heuristike), len(randomnesses), len(gradovi)), dtype=float)

PomocneFunkcije.ucitajUdaljenosti()

#@ray.remote
def itera(heur, population_size, grad_index, randomness):
    vrijeme_na_pocetku = time.time()
    population, population_fitness = PomocneFunkcije.makePopulation(heur, population_size, grad_index, randomness)
    najbolje_rjesenje = PomocneFunkcije.algorithm(population, population_fitness, population_size, grad_index)
    vrijeme = time.time() - vrijeme_na_pocetku
    rjesenje = int(PomocneFunkcije.evaluate(najbolje_rjesenje))
    print("\t\t\t\tVrijeme: " + str(vrijeme))
    print("\t\t\t\tRezultat: " + str(rjesenje))
    return vrijeme, rjesenje

#vrijeme, rjesenje = itera(heuristike[0], population_size, gradovi[0], randomnesses[0])
#print(vrijeme)
#print(rjesenje)
# ray.shutdown()
# ray.init(num_cpus=7)

for h, heur in enumerate(heuristike):
    print("Heuristika: " + imena_heuristika[h])
    for r, randomness in enumerate(randomnesses):
        print("\tRandomness: " + str(randomness*100) + "%")
        for g, grad in enumerate(gradovi):
            print("\t\tGrad: " + imena_gradova[g] + " (" + str(g) + ")")
            for i in range(broj_eksperimenata):
                #if rjesenja[h,r,g,i] > 0:
                print("\t\t\tEksperiment: " + str(i))
                # ref = itera.remote(heur, population_size, grad, randomness)
                # vremena, rjesenja = ray.get(ref)
                vremena[h,r,g,i], rjesenja[h,r,g,i] = itera(heur, population_size, g, randomness)
                np.save('data', rjesenja)
                np.save('times', vremena)
            break
        break # da se ne računa previše, točnije samo jedan randomness
    break  # također da se ne računa previše, točnije samo jedna heuristika

def prikaziRezultate():
    for h, heur in enumerate(heuristike):
        print("Heuristika: " + imena_heuristika[h])
        for r, randomness in enumerate(randomnesses):
            for g, grad in enumerate(gradovi):
                average_fitness = 0
                average_time = 0
                for i in range(broj_eksperimenata):
                    average_fitness += rjesenja[h,r,g,i]
                    average_time += vremena[h,r,g,i]
                    
                average_fitness /= broj_eksperimenata
                average_fitness_arr[h,r,g] = average_fitness
                
                average_time /= broj_eksperimenata
                average_times[h,r,g] = average_time
                
                stdev_arr[h,r,g] = np.std(rjesenja[h,r,g])
            info = {'Grad': imena_gradova, 'Avg.': average_fitness_arr[h,r], 'St. dev.': stdev_arr[h,r], 'Avg. time': average_times[h,r]}
            print("Randomness: " + str(randomness*100) + "%")
            print(tabulate(info, headers='keys', tablefmt='fancy_grid'))
            break # da se ne računa previše, točnije samo jedan randomness
        break  # također da se ne računa previše, točnije samo jedna heuristika
        
prikaziRezultate()
