import random
from pomocne import PomocneFunkcije

class NearestNeighbour:

    def generate_solution(gradovi, solution_heur):
        
        solution = []
        slucajniIndeks = random.randint(0, len(gradovi)-1)
        solution.append(gradovi[slucajniIndeks])
        gradovi.pop(slucajniIndeks)
    
        br = 1
        
        while br < solution_heur:
            tmp = solution[-1]
            min_d = 1000000
            min_g = []
            min_i = 0
            for i in range(len(gradovi)):
                d = PomocneFunkcije.udaljenost(gradovi[i][1], tmp[1], gradovi[i][2], tmp[2])
                if d < min_d:
                    min_d = d
                    min_g = gradovi[i]
                    min_i = i
            gradovi.pop(min_i)
            solution.append(min_g)
            br += 1
            
        while br < len(gradovi):
            slucajniIndeks = random.randint(0, len(gradovi)-1)
            solution.append(gradovi[slucajniIndeks])
            gradovi.pop(slucajniIndeks)
            br += 1
        return solution