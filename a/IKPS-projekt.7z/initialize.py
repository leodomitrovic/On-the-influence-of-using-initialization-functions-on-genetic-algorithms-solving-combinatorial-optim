from nn import NearestNeighbour
from insertion import Insertion
from i1 import I1
from pomocne import PomocneFunkcije
from gradovi import Gradovi
import numpy as np
from tabulate import tabulate
import time

# TODO: uvjet terminacije u Pomocne popraviti, umjesto hardkodiranog broja (napravili smo već to samo ne mogu naći)
# TODO: saznati imena gradova pod indeksima 13, 14, 15
# TODO: friedman's test, kod uspoređivanja različitih genetskih algoritama usporediti grad po grad, znači usporediti  prosjek od rješenje[heur=0,rand,grad] sa rješenje[heur=1,rand,grad]

# provjeriti je li u znanstvenom radu pod "time" (engl.) izračunato kao "vrijeme od početka pa do kraja računanja svih 50 eksperimenata za specifičnu heuristiku, randomness i grad" ili average ili median

gradovi = Gradovi.gradovi
imena_gradova = Gradovi.imena_gradova
imena_heuristika = ["Nearest Neighbour", "Insertion", "Solomon I1"]

population_size = 10
broj_eksperimenata = 2 # potrebno za pravi eksperiment staviti na 50, zbog bržeg izračuna sada je 2

heuristike = [NearestNeighbour, Insertion, I1]
randomnesses = [1, 0.5, 0.1, 0]

rjesenja = np.empty((len(heuristike), len(randomnesses), len(gradovi), broj_eksperimenata), dtype=int)
vremena = np.empty((len(heuristike), len(randomnesses), len(gradovi), broj_eksperimenata), dtype=float)

average_fitness_arr = np.empty((len(heuristike), len(randomnesses), len(gradovi)), dtype=float)
stdev_arr = np.empty((len(heuristike), len(randomnesses), len(gradovi)), dtype=float)
average_times = np.empty((len(heuristike), len(randomnesses), len(gradovi)), dtype=float)

for h, heur in enumerate(heuristike):
    print("Heuristika: " + imena_heuristika[h])
    for r, randomness in enumerate(randomnesses):
        print("Randomness: " + str(randomness*100) + "%")
        for g, grad in enumerate(gradovi):
            print("Grad: " + imena_gradova[g] + " (" + str(g) + ")")
            for i in range(broj_eksperimenata):
                #print("Eksperiment: " + str(i))
                vrijeme_na_pocetku = time.time()
                population, population_fitness = PomocneFunkcije.makePopulation(heur, population_size, grad, randomness)
                najbolje_rjesenje = PomocneFunkcije.algorithm(population, population_fitness, population_size)
                vremena[h,r,g,i] = time.time() - vrijeme_na_pocetku
                rjesenja[h,r,g,i] = int(PomocneFunkcije.evaluate(najbolje_rjesenje))
        break # da se ne računa previše, točnije samo jedan randomness
    break  # također da se ne računa previše, točnije samo jedna heuristika

# https://towardsdatascience.com/how-to-easily-create-tables-in-python-2eaea447d8fd

def prikaziRezultate():
    for h, heur in enumerate(heuristike):
        print("Heuristika: " + imena_heuristika[h])
        for r, randomness in enumerate(randomnesses):
            for g, grad in enumerate(gradovi):
                average_fitness = 0
                average_time = 0
                for i in range(broj_eksperimenata):
                    average_fitness += rjesenja[h,r,g,i]
                    average_time += vremena[h,r,g,i]
                    
                average_fitness /= broj_eksperimenata
                average_fitness_arr[h,r,g] = average_fitness
                
                average_time /= broj_eksperimenata
                average_times[h,r,g] = average_time
                
                stdev_arr[h,r,g] = np.std(rjesenja[h,r,g])
            info = {'Grad': imena_gradova, 'Avg.': average_fitness_arr[h,r], 'St. dev.': stdev_arr[h,r], 'Avg. time': average_times[h,r]}
            print("Randomness: " + str(randomness*100) + "%")
            print(tabulate(info, headers='keys', tablefmt='fancy_grid'))
            break # da se ne računa previše, točnije samo jedan randomness
        break  # također da se ne računa previše, točnije samo jedna heuristika

prikaziRezultate()