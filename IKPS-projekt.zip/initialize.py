from nn import NearestNeighbour
from insertion import Insertion
from i1 import I1
from pomocne import PomocneFunkcije
from gradovi import Gradovi
import numpy as np
from tabulate import tabulate
import time
import ray
import winsound

ray.shutdown()
ray.init()

gradovi = Gradovi.gradovi
imena_gradova = Gradovi.imena_gradova
imena_heuristika = ["NN", "In", "I1"]
population_size = 48
broj_eksperimenata = 5

heuristike = [NearestNeighbour, Insertion, I1]
randomnesses = [1, 0.5, 0.1, 0]

rjesenja = np.load('data.npy')
vremena = np.load('times.npy')

if len(rjesenja) == 0:
    rjesenja = np.zeros((len(heuristike), len(randomnesses), len(gradovi), 50))
    vremena = np.zeros((len(heuristike), len(randomnesses), len(gradovi), 50))

average_fitness_arr = np.zeros((len(heuristike), len(randomnesses), len(gradovi)), dtype=float)
stdev_arr = np.zeros((len(heuristike), len(randomnesses), len(gradovi)), dtype=float)
average_times = np.zeros((len(heuristike), len(randomnesses), len(gradovi)), dtype=float)

def reset_saved_data():
    rjesenja = np.zeros((len(heuristike), len(randomnesses), len(gradovi), 50))
    vremena = np.zeros((len(heuristike), len(randomnesses), len(gradovi), 50))
    np.save('data', rjesenja)
    np.save('times', vremena)

@ray.remote
def itera(h, population_size, grad, randomness, indeks_grada, broj_eksperimenta, brojac):
    vrijeme_na_pocetku = time.time()
    population, population_fitness = PomocneFunkcije.makePopulation(heuristike[h], population_size, grad, randomness)
    najbolje_rjesenje = PomocneFunkcije.algorithm(population, population_fitness, population_size, imena_gradova[indeks_grada] + ":" + str(randomness) + ":" + imena_heuristika[h])
    vrijeme = time.time() - vrijeme_na_pocetku
    rjesenje = int(PomocneFunkcije.evaluate(najbolje_rjesenje))
    print("Tsp problem: " + imena_heuristika[h] + ":" + str(randomness*100) + "%:" + imena_gradova[indeks_grada] + ":" + str(broj_eksperimenta) + " (" + str(brojac) + "/50)")
    print("Time: {0:.0f} seconds".format(vrijeme))
    print("Fitness: " + str(rjesenje))
    return (vrijeme, rjesenje)

while True:
    
    brojac = 0
    maks_brojac = 50
    
    zadaci = []
    postavke_zadataka = []

    for h, heur in enumerate(heuristike):
        for r, randomness in enumerate(randomnesses):
            if r == 3 and h != 0:
                continue
            for g, grad in enumerate(gradovi):
                for i in range(broj_eksperimenata):
                    if abs(rjesenja[h,r,g,i]) < 0.1:
                                                
                        if brojac >= maks_brojac:
                            break
                        
                        zadaci.append(itera.remote(h, population_size, grad, randomness, g, i, brojac))
                        postavke_zadataka.append((h,r,g,i))
                        brojac += 1
                                                
                        print("Dodano u red izvrsavanja: " + imena_heuristika[h] + ":" + str(randomness*100) + "%:" + imena_gradova[g] + ":" + str(i) + " (" + str(brojac) + "/50)")

                if brojac >= maks_brojac:
                    break
            if brojac >= maks_brojac:
                break
        if brojac >= maks_brojac:
            break
    
    if brojac > 0:
    
        ray_rjesenja = ray.get(zadaci)
        
        for i, p in enumerate(postavke_zadataka):
            
            rjesenja[p[0],p[1],p[2],p[3]] = float(ray_rjesenja[i][1])
            vremena[p[0],p[1],p[2],p[3]] = float(ray_rjesenja[i][0])
        
        print("Spremanje rezultata...")
        
        np.save('data', rjesenja)
        np.save('data_backup', rjesenja)
        np.save('times', vremena)
        np.save('times_backup', vremena)
        
        print("Rezultati spremljeni!")
        
        frequency = 2500  # Set Frequency To 2500 Hertz
        duration = 1000  # Set Duration To 1000 ms == 1 second
        winsound.Beep(frequency, duration)
    else:
        break

def prikaziRezultate():
    for h, heur in enumerate(heuristike):
        print("Heuristika: " + imena_heuristika[h])
        for r, randomness in enumerate(randomnesses):
            nije_prazno = False
            for g, grad in enumerate(gradovi):
                average_fitness = 0
                average_time = 0
                for i in range(broj_eksperimenata):
                    if abs(rjesenja[h,r,g,i]) > 0.1:
                        nije_prazno = True
                    average_fitness += rjesenja[h,r,g,i]
                    average_time += vremena[h,r,g,i]
                    
                average_fitness /= broj_eksperimenata
                average_fitness_arr[h,r,g] = average_fitness
                
                average_time /= broj_eksperimenata
                average_times[h,r,g] = average_time
                
                stdev_arr[h,r,g] = np.std(rjesenja[h,r,g,0:broj_eksperimenata])
            if nije_prazno:
                info = {'Grad': imena_gradova, 'Avg.': average_fitness_arr[h,r], 'St. dev.': stdev_arr[h,r], 'Avg. time': average_times[h,r]}
                print("Randomness: " + str(randomness*100) + "%")
                print(tabulate(info, headers='keys', tablefmt='fancy_grid'))

prikaziRezultate()
