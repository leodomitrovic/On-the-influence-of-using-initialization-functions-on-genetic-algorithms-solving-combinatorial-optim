from pomocne import PomocneFunkcije
import time
from nn import NearestNeighbour
from gradovi import Gradovi
    
grad = 7

def TwoOpt(solution, withwhile=True):
    debugging = False
    
    najbolja_udaljenost = PomocneFunkcije.evaluate(solution)
    improvement_threshold=0.001
    improvement_factor = 1
    
    print("twoopt start")
    
    vremena_izvrsavanja = []
    pocetno_vrijeme = time.time()*1000
    
    br = 0
    improved = True
    while withwhile or br < 1:
        
        previous_best = najbolja_udaljenost
        improved = False
        for i in range(0, len(solution) - 2):
            for j in range(i + 2, len(solution) - 1):
                if j - i == 1:
                    continue
                u1 = i
                u2 = i + 1
                v1 = j
                v2 = j + 1
    
                d1 = PomocneFunkcije.udaljenost(solution[u1][1], solution[u1][2], solution[u2][1], solution[u2][2])
                d2 = PomocneFunkcije.udaljenost(solution[v1][1], solution[v1][2], solution[v2][1], solution[v2][2])
                
                d1_new = PomocneFunkcije.udaljenost(solution[u1][1], solution[u1][2], solution[v1][1], solution[v1][2])
                d2_new = PomocneFunkcije.udaljenost(solution[u2][1], solution[u2][2], solution[v2][1], solution[v2][2])

                old = d1 + d2
                new = d1_new + d2_new
                
                if new < old:
                    br += 1

                    obrnuto = solution[u2:v1+1]
                    obrnuto.reverse()
                    solution[u2:v1+1] = obrnuto

                    improved = True
                    break
            if improved and withwhile:
                break
        if not improved:
            break
    
    print("vrijeme: " + str(time.time()*1000-pocetno_vrijeme) + " broj zamjena: " + str(br))
    return solution

solution = [[1, 0, 0], [2, 300, 0], [3, 310, 30], [4, 270, 30], [5, 80, 30], [6, 15, 30], [7, 15, 40], [8, 80, 40], [9, 270, 40], [10, 310, 40], [11, 300, 70], [12, 0, 70], [13, 0, 0]]

PomocneFunkcije.nacrtaj(solution, "prije 2-opt")

solution = TwoOpt(solution)
PomocneFunkcije.nacrtaj(solution, "nakon 2-opt")

"""first = NearestNeighbour.generate_solution(Gradovi.gradovi[grad], len(Gradovi.gradovi[grad]))
second = NearestNeighbour.generate_solution(Gradovi.gradovi[grad], len(Gradovi.gradovi[grad]))

while True:

    solution1 = PomocneFunkcije.OrderCrossover(first, second)
    solution2 = PomocneFunkcije.OrderCrossover(second, first)
        
    solution1 = TwoOpt(solution1)
    solution2 = TwoOpt(solution2)
    
    first = solution1
    second = solution2"""