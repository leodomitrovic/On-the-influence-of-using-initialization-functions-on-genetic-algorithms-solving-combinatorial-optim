# -*- coding: utf-8 -*-
"""
Created on Fri Jul  9 12:03:48 2021

@author: Krepana Krava
"""

import numpy as np

from tabulate import tabulate

rjesenja = np.load('data.npy')
#vremena = np.load('times.npy')

heuristike = 3
gradovi = 15
randomnesses = 4
broj_eksperimenata = 50

brojac_popunjenih = 0

#for i in range(10):
#    print(rjesenja[0,0,11,i])

#print(np.std(rjesenja[0,0,11, 0:10]))
#print(np.std([74629.0,74079.0,74235.0,74309.0,75141.0,74455.0,73843.0,74376.0,74729.0,74113.0]))

for h in range(heuristike):
    for r in range(randomnesses):
        
        for g in range(gradovi):
            nije_prazno = False
            average_fitness = 0
            average_time = 0
            for i in range(broj_eksperimenata):
                if abs(rjesenja[h,r,g,i]) > 0.1:
                    nije_prazno = True
                    brojac_popunjenih += 1
                average_fitness += rjesenja[h,r,g,i]
                #average_time += vremena[h,r,g,i]
                
            average_fitness /= broj_eksperimenata
            #average_fitness_arr[h,r,g] = average_fitness
            
            average_time /= broj_eksperimenata
           # average_times[h,r,g] = average_time
            if nije_prazno:
               print("{0},{1},{2}".format(h,r,g))
print(brojac_popunjenih)