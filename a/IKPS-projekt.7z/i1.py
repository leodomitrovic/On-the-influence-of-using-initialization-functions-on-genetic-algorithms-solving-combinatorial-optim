import random
from pomocne import PomocneFunkcije

class I1:

    def generate_solution(gradovi, solution_heur):
            
        gradovi_copy = gradovi[:]
        solution = []
        
        slucajniIndeks = random.randint(0, len(gradovi_copy)-1)
        solution.append(gradovi_copy[slucajniIndeks])
        gradovi_copy.pop(slucajniIndeks)
        
        slucajniIndeks = random.randint(0, len(gradovi_copy)-1)
        solution.append(gradovi_copy[slucajniIndeks])
        gradovi_copy.pop(slucajniIndeks)

        br = 1
        
        while br < solution_heur:
            
            min_p_d = 100000
            min_p_i = -1
            min_p_g = -1
            for i in range(len(solution)):
                for j in range(len(gradovi_copy)):
                    d = PomocneFunkcije.udaljenost(solution[i][1], gradovi_copy[j][1], solution[i][2], gradovi_copy[j][2]) + PomocneFunkcije.udaljenost(solution[i-1][1], gradovi_copy[j][1], solution[i-1][2], gradovi_copy[j][2])
                    if d < min_p_d:
                        min_p_d = d
                        min_p_i = i
                        min_p_g = j
            solution.insert(min_p_i, gradovi_copy[min_p_g])
            gradovi_copy.pop(min_p_g)
            br += 1

        while br < len(gradovi_copy):
            slucajniIndeks = random.randint(0, len(gradovi_copy)-1)
            solution.append(gradovi_copy[slucajniIndeks])
            gradovi_copy.pop(slucajniIndeks)
            br += 1
        return solution