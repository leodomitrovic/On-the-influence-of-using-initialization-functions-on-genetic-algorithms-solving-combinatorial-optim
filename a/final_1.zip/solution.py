import random
from gradovi import Gradovi

class Solution:
    
    def __init__(self, tsp_index, cvorovi=[]):
        self.tsp_index = tsp_index
        self.cvorovi = cvorovi[:]
        self.fitness = 0
        #print("This is Constructor")

    def add(self, indeks_cvora):
        if indeks_cvora in self.cvorovi:
            print("index {0} already in".format(indeks_cvora))
        else:
            self.cvorovi.append(indeks_cvora)
        
    def get(self, indeks_polja):
        return self.cvorovi[indeks_polja]
    
    def __contains__(self, key):
        return key in self.cvorovi
    
    def __len__(self):
        return len(self.cvorovi)
    
    def __str__(self):
        return "Tsp-index: {0}\nCvorovi: {1}".format(self.tsp_index,self.cvorovi)
