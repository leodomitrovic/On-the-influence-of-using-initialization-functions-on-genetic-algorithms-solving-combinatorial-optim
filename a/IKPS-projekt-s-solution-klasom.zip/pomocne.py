import numpy as np
import matplotlib.pyplot as plt
import random
import time
import ray
from gradovi import Gradovi
from solution import Solution

class PomocneFunkcije:
    #population = []
    #population_fitness = []
    #population_size = 0
    
    udaljenosti = []
    
    def ucitajUdaljenosti():
        global udaljenosti
        udaljenosti = np.load('udaljenosti.npy', allow_pickle=True)

    
    def makePopulation(heuristika, population_size, tsp_index, randomness):
        
        # Inicijalizacija      
        population = []
        population_fitness = []
        
        gradovi_len = len(Gradovi.gradovi[tsp_index])
        
        if randomness == 1:
            solution_heur = gradovi_len
        elif randomness == 0.5:
            solution_heur = int(gradovi_len / 2)
        elif randomness == 0.1:
            solution_heur = int(gradovi_len * 0.1)
        else: 
            solution_heur = 0
        
        for i in range(population_size):
            heur = heuristika(tsp_index)
            solution = heur.generate_solution(solution_heur)
            #random.shuffle(solution)
            population.append(solution)
            population_fitness.append(PomocneFunkcije.evaluate(solution))
        #print("population made")
        return population, population_fitness
    
    
   # vraća novo dijete
   
    def OrderCrossover(first, second):
        #print("Crossover")
        first_crossover = random.randint(0, len(first.cvorovi)-1)
        
        while True:
            second_crossover = random.randint(0, len(first.cvorovi)-1)
            if first_crossover != second_crossover:
                break
            
        tmp1 = first_crossover
        tmp2 = second_crossover
        first_crossover = min(tmp1, tmp2)
        second_crossover = max(tmp1, tmp2)
        
        child = Solution(first.tsp_index, first.cvorovi[first_crossover:second_crossover])
        
        for i in range(second_crossover, second_crossover + len(second.cvorovi)):
            index = i % len(second.cvorovi)
            if second.get(index) not in child:
                #print("addinggg")
                child.add(second.get(index))

        return child
    
    def nacrtaj(population, title):
        x = [Gradovi.gradovi[item.tsp_index][item][1] for item in population]
        y = [Gradovi.gradovi[item.tsp_index][item][2] for item in population]
        plt.plot(x, y)
        plt.plot(x, y, 'ro')
        plt.title(title)
        plt.show()
    
    def algorithm(population, population_fitness, population_size, indeks_grada):
        brojac = 0
        ukupno = 0
        #end = PomocneFunkcije.calculate_end(grad_size)
        min_res = []
        min_fitness = 100000
        
        best_fitnesses = []
        
        while True:
            if brojac == 100:
                break

            #elitizam
            ELITIST_SIZE = int(population_size/2)
            elitists = population[:ELITIST_SIZE]
            elitists_fitness = population_fitness[:ELITIST_SIZE]
            
            offspring, offspring_fitness = PomocneFunkcije.generate(population)
            
            population += offspring
            population_fitness += offspring_fitness
            
            """for i in range(len(population)):
                if np.random.rand() < 0.1:
                    population[i] = PomocneFunkcije.TwoOpt(population[i])
                    population_fitness[i] = PomocneFunkcije.evaluate(population[i])
              """      
            for i in reversed(range(len(population))):
                if population[i] in elitists:
                    del population[i]
                    del population_fitness[i]
            
            # Sort
            for _ in range(len(population)):
                for j in range(len(population) - 1):
                    if population_fitness[j] > population_fitness[j+1]:
                        population[j], population[j+1] = population[j+1], population[j]
                        population_fitness[j], population_fitness[j+1] = population_fitness[j+1], population_fitness[j]
                        
            
            
            #roulette wheel
            rws = population_fitness[:]
            #rws = [print(k) for k in rws]
            rws = [k ** (-1) for k in rws]
            rws = rws  / np.sum(rws)
            rws = np.cumsum(rws)
            
            # Elitizam
            half = int(population_size / 2)
            br = 0
            while br < half:
                slucajni = np.random.rand()
                
                for i in range(len(population)):
                    if slucajni <= rws[i]:
                        elitists.append(population[i])
                        population.pop(i)
                        population_fitness.pop(i)
                        rws = population_fitness[:]
                        rws = [k ** (-1) for k in rws]
                        rws = rws  / np.sum(rws)
                        rws = np.cumsum(rws)
                        br += 1
                        break
                
            population = []
            population_fitness = []
            population = elitists[:]
            for i in range(0, len(population)):
                population_fitness.append(PomocneFunkcije.evaluate(population[i]))
            
            # Sort
            for _ in range(len(population)):
                for j in range(len(population) - 1):
                    if population_fitness[j] > population_fitness[j+1]:
                        population[j], population[j+1] = population[j+1], population[j]
                        population_fitness[j], population_fitness[j+1] = population_fitness[j+1], population_fitness[j]


            #print("Min: {:.2f}\tMean: {:.2f}\tMax: {:.2f}".format(np.min(population_fitness), np.mean(population_fitness), np.max(population_fitness)))
            if population_fitness[0] < min_fitness:
                #min_res = population[0]
                min_fitness = population_fitness[0]
                brojac = 0
            else:
                brojac += 1
            #ukupno += 1
            print(brojac)
            
            # uzmi fitness najbolje jedinke da kasnije napravimo graf najboljeg fitnessa po iteracijama
            best_fitnesses.append(population_fitness[0])
        
        #print (ukupno)
        # nacrtaj kako se fitness poboljšavao
        x = np.arange(len(best_fitnesses))
        y = best_fitnesses
        plt.plot(x, y)
        plt.show()
        return population[0]
    
    def spremljena_udaljenost(index1, index2, grad):
        global udaljenosti
        
        tmp1 = index1
        tmp2 = index2
        index1 = min(tmp1, tmp2)
        index2 = max(tmp1, tmp2)
        
        return float(udaljenosti[grad][index1][index2])
        """x1 = Gradovi.gradovi[grad][index1][1]
        y1 = Gradovi.gradovi[grad][index1][2]
        x2 = Gradovi.gradovi[grad][index2][1]
        y2 = Gradovi.gradovi[grad][index2][2]
        
        return np.sqrt(pow(x1 - x2, 2) + pow(y1 - y2, 2)) """
    
    def udaljenost(x1, y1, x2, y2):
        manhattan_udaljenost = False
        
        if manhattan_udaljenost:
            return abs(x1 - x2) + abs(y1 - y2) 
        else:
            return np.sqrt(pow(x1 - x2, 2) + pow(y1 - y2, 2)) 
    
    def generate(population):
        offspring = []
        offspring_fitness = []
        
        faktor_povecanja_djece = 1
        max_number_of_offsprings = len(population)*faktor_povecanja_djece
        for i in range(len(population)):
            if (np.random.rand() < 0.9):
                first = i
                second = -1
                while True:
                    second = np.random.randint(len(population))
                    if first != second:
                        break
                    
                first_child = PomocneFunkcije.OrderCrossover(population[first], population[second])
                second_child = PomocneFunkcije.OrderCrossover(population[second], population[first])
                
                if np.random.rand() < 0.1:
                    first_child = PomocneFunkcije.TwoOpt(first_child)
                    
                if np.random.rand() < 0.1:
                    second_child = PomocneFunkcije.TwoOpt(second_child)
                
                offspring.append(first_child)
                offspring.append(second_child)
                offspring_fitness.append(PomocneFunkcije.evaluate(first_child))
                offspring_fitness.append(PomocneFunkcije.evaluate(second_child))
                if len(offspring) >= max_number_of_offsprings:
                    break
        #print("Made " + str(len(offspring)) + " children")
        return offspring, offspring_fitness
    
    
    def calculate_end(n):
        kraj = n
        
        for i in range(1, n + 1):
            kraj += i
        
        return kraj
    
    def evaluate(solution):
        dist = 0

        for i in range(0, len(solution) - 1):
            #dist += PomocneFunkcije.udaljenost(solution[i][1], solution[i][2], solution[i + 1][1], solution[i + 1][2])
            dist += PomocneFunkcije.spremljena_udaljenost(solution.cvorovi[i], solution.cvorovi[i + 1], solution.tsp_index)
        #dist += PomocneFunkcije.udaljenost(solution[-1][1], solution[-1][2], solution[0][1], solution[0][2])
        dist += PomocneFunkcije.spremljena_udaljenost(solution.cvorovi[-1], solution.cvorovi[0], solution.tsp_index)
        return dist
    
    def TwoOpt(solution):
        debugging = False
        
        najbolja_udaljenost = PomocneFunkcije.evaluate(solution)
        improvement_threshold=0.001
        improvement_factor = 1
        
        br = 0
        improved = True
        while improved:
            
            previous_best = najbolja_udaljenost
            improved = False
            for i in range(0, len(solution) - 2):
                
                for j in range(i + 2, len(solution) - 1):
                    if j - i == 1:
                        continue
                    u1 = i
                    u2 = i + 1
                    v1 = j
                    v2 = j + 1
        
                    #d1 = PomocneFunkcije.udaljenost(solution[u1][1], solution[u1][2], solution[u2][1], solution[u2][2])
                    #d2 = PomocneFunkcije.udaljenost(solution[v1][1], solution[v1][2], solution[v2][1], solution[v2][2])
                    d1 = PomocneFunkcije.spremljena_udaljenost(solution.cvorovi[u1], solution.cvorovi[u2], solution.tsp_index)
                    d2 = PomocneFunkcije.spremljena_udaljenost(solution.cvorovi[v1], solution.cvorovi[v2], solution.tsp_index)

                    
                    #d1_new = PomocneFunkcije.udaljenost(solution[u1][1], solution[u1][2], solution[v1][1], solution[v1][2])
                    #d2_new = PomocneFunkcije.udaljenost(solution[u2][1], solution[u2][2], solution[v2][1], solution[v2][2])
                    d1_new = PomocneFunkcije.spremljena_udaljenost(solution.cvorovi[u1], solution.cvorovi[v1], solution.tsp_index)
                    d2_new = PomocneFunkcije.spremljena_udaljenost(solution.cvorovi[u2], solution.cvorovi[v2], solution.tsp_index)
                    
                    old = d1 + d2
                    new = d1_new + d2_new
                    
                    if new < old:
                        br += 1

                        obrnuto = solution.cvorovi[u2:v1+1]
                        obrnuto.reverse()
                        solution.cvorovi[u2:v1+1] = obrnuto

                        if debugging:
                            PomocneFunkcije.nacrtaj(solution, "2-opt")
                        improved = True
                        break
                if improved:
                    break

            improvement_factor = 1 - najbolja_udaljenost/previous_best
            #break
            
        return solution
