import random
from pomocne import PomocneFunkcije
from gradovi import Gradovi
from solution import Solution

class NearestNeighbour:
    
    def __init__(self, tsp_index):
        self.solution = Solution(tsp_index)
        self.tsp_index = tsp_index

    def generate_solution(self, solution_heur):
        
        #print(self.solution)
        cvorovi = list(range(len(Gradovi.gradovi[self.tsp_index])))
        
        slucajniIndeks = random.randint(0, len(cvorovi)-1)
        self.solution.add(slucajniIndeks)
        cvorovi.pop(slucajniIndeks)
    
        br = 1
        
        while br < solution_heur:
            tmp = self.solution.get(-1)
            min_g = -1
            min_d = 1000000
            min_i = -1
            for i in range(len(cvorovi)):
                d = PomocneFunkcije.spremljena_udaljenost(cvorovi[i], tmp, self.tsp_index)
                if d < min_d:
                    min_d = d
                    min_g = cvorovi[i]
                    min_i = i
            if min_i == -1:
                break
            cvorovi.pop(min_i)
            #print("Dodavanje")
            self.solution.add(min_g)
            br += 1
            
        while br < len(cvorovi):
            slucajniIndeks = random.randint(0, len(cvorovi)-1)
            #print("Random dodavanje")
            self.solution.add(slucajniIndeks)
            cvorovi.pop(slucajniIndeks)
            br += 1
        #print(self.solution)
        return self.solution