# -*- coding: utf-8 -*-
"""
Created on Fri Jul  9 12:03:48 2021

@author: Krepana Krava
"""

import numpy as np

from pomocne import PomocneFunkcije
from gradovi import Gradovi

from tabulate import tabulate
import pandas as pd


rjesenja = np.load('data.npy')
vremena = np.load('times.npy')

heuristike = 3

brojac_popunjenih = 0



imena_gradova = Gradovi.imena_gradova
imena_heuristika = ["NN", "In", "I1"]
population_size = 48
broj_eksperimenata = 5 # potrebno za pravi eksperiment staviti na 50, zbog bržeg izračuna sada je 2

randomnesses = [1, 0.5, 0.1, 0]


gradovi = []
average_fitness_arr = []
fitstdev_arr = []
timestdev_arr = []
average_times = []
heurs = []

arrej = np.zeros((len(imena_gradova), 4*4), dtype=float)

#for i in range(10):
#    print(rjesenja[0,0,11,i])

#print(np.std(rjesenja[0,0,11, 0:10]))
#print(np.std([74629.0,74079.0,74235.0,74309.0,75141.0,74455.0,73843.0,74376.0,74729.0,74113.0]))

for h in range(heuristike):
    for r in range(len(randomnesses)):
        
        for g in range(15):
            nije_prazno = False
            average_fitness = 0
            average_time = 0
            for i in range(broj_eksperimenata):
                if abs(rjesenja[h,r,g,i]) > 0.1:
                    nije_prazno = True
                    brojac_popunjenih += 1
                average_fitness += rjesenja[h,r,g,i]
                #average_time += vremena[h,r,g,i]
                
            average_fitness /= broj_eksperimenata
            #average_fitness_arr[h,r,g] = average_fitness
            
            average_time /= broj_eksperimenata
           # average_times[h,r,g] = average_time
            if nije_prazno:
               print("{0},{1},{2}".format(h,r,g))
print(brojac_popunjenih)

def prikaziRezultate():
    h = 2
    #print("Heuristika: " + imena_heuristika[h])
    for r, randomness in enumerate(randomnesses):
        nije_prazno = False
        for g in range(15):
            average_fitness = 0
            average_time = 0
            for i in range(broj_eksperimenata):
                if abs(rjesenja[h,r,g,i]) > 0.1:
                    nije_prazno = True
                average_fitness += rjesenja[h,r,g,i]
                average_time += vremena[h,r,g,i]
                
            average_fitness /= broj_eksperimenata
            average_fitness_arr.append(average_fitness)
            
            average_time /= broj_eksperimenata
            average_times.append(average_time)
            
            fitstdev = np.std(rjesenja[h,r,g,0:broj_eksperimenata])
            timestdev = np.std(vremena[h,r,g,0:broj_eksperimenata])
            
            fitstdev_arr.append(fitstdev)
            timestdev_arr.append(timestdev)
            heurs.append(h)
            gradovi.append(g)
            

            
            arrej[g][(4*r)] = average_fitness
            arrej[g][(4*r)+1] = fitstdev
            arrej[g][(4*r)+2] = average_time
            arrej[g][(4*r)+3] = timestdev
            print(rjesenja[h,r,g,0])
                
            #if nije_prazno:
                #info = {'Grad': imena_gradova, 'Avg.': average_fitness_arr[h,r], 'St. dev.': fitstdev_arr[h,r], 'Avg. time': average_times[h,r]}
                #print("Randomness: " + str(randomness*100) + "%")
                #print(tabulate(info, headers='keys', tablefmt='fancy_grid'))
            #break # da se ne računa previše, točnije samo jedan randomness
  # također da se ne računa previše, točnije samo jedna heuristika
        
prikaziRezultate()

data = {
        'City': gradovi,
        'Average fitness': average_fitness_arr,
        'Fitness st. dev.': fitstdev_arr,
        'Average time': average_times,
        'Time st. dev.': timestdev_arr,
        'Heur': heurs,
        }

#df = pd.DataFrame(data)
#lala = df.groupby(['Heur'])['City'].count()
#print (lala)
#np.savetxt('krava.txt', arrej, delimiter=',', dtype=int) 

arrays = [
    np.array(["1", "1", "1", "1", "0.5", "0.5", "0.5", "0.5", "0.1", "0.1", "0.1", "0.1", "0", "0", "0", "0"]), #randomness
    np.array(["fitness", "fit.st.dev.", "time", "time st.dev.","fitness", "fit.st.dev.", "time", "time st.dev.","fitness", "fit.st.dev.", "time", "time st.dev.","fitness", "fit.st.dev.", "time", "time st.dev."]), #stupci koje trebamo
]

imena_gradova = ["berlin52", "st70", "eil76", "kroA100", "kroB100", "kroC100", "eil101", "pr107", "pr124", "pr136", "pr144", "pr152", "oliver30","eilon50","eilon75"]


df = pd.DataFrame(arrej)
#lol = df.transpose
print(df)
df.to_csv('out.csv')