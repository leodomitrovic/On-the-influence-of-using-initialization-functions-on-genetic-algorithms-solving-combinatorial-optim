# -*- coding: utf-8 -*-
"""
Created on Tue Jul  6 13:32:45 2021

@author: Krepana Krava
"""

from pomocne import PomocneFunkcije
from gradovi import Gradovi
import numpy as np

gradovi = Gradovi.gradovi

broj_gradova = len(gradovi)




gradovi_s_udaljenostima = []
itera = 0
for i, grad in enumerate(gradovi):
    broj_jova = len(grad)
    udaljenosti_u_pojedinom_gradu = np.zeros(( broj_jova, broj_jova ), dtype=float)

    for j in range(broj_jova):
        for k in range(j+1, broj_jova):
            
            udaljenosti_u_pojedinom_gradu[j, k] = float(PomocneFunkcije.udaljenost(gradovi[i][j][1], gradovi[i][j][2], gradovi[i][k][1], gradovi[i][k][2]))
            
    gradovi_s_udaljenostima.append(udaljenosti_u_pojedinom_gradu)

np.save('udaljenosti', gradovi_s_udaljenostima)