from nn import NearestNeighbour
from insertion import Insertion
from i1 import I1
from pomocne import PomocneFunkcije
from gradovi import Gradovi
import numpy as np
from tabulate import tabulate
import time
from os import path

# TODO: friedman's test, kod uspoređivanja različitih genetskih algoritama usporediti grad po grad, znači usporediti  prosjek od rješenje[heur=0,rand,grad] sa rješenje[heur=1,rand,grad]

gradovi = Gradovi.gradovi
imena_gradova = Gradovi.imena_gradova
imena_heuristika = ["Nearest Neighbour", "Insertion", "Solomon I1"]

population_size = 48
broj_eksperimenata = 50 # potrebno za pravi eksperiment staviti na 50, zbog bržeg izračuna sada je 2

heuristike = [NearestNeighbour, Insertion, I1]
randomnesses = [1, 0.5, 0.1, 0]

if path.exists('data.npy'):
    rjesenja = np.load('data.npy')
else:
    rjesenja = np.empty((len(heuristike), len(randomnesses), len(gradovi), broj_eksperimenata), dtype=np.float64)

if path.exists('times.npy'):
    vremena = np.load('times.npy')
else:
    vremena = np.empty((len(heuristike), len(randomnesses), len(gradovi), broj_eksperimenata))

average_fitness_arr = np.empty((len(heuristike), len(randomnesses), len(gradovi)), dtype=np.float64)
stdev_arr = np.empty((len(heuristike), len(randomnesses), len(gradovi)), dtype=np.float64)
average_times = np.empty((len(heuristike), len(randomnesses), len(gradovi)), dtype=np.float64)

for h, heur in enumerate(heuristike):
    print("Heuristika: " + imena_heuristika[h])
    for r, randomness in enumerate(randomnesses):
        print("Randomness: " + str(randomness*100) + "%")
        for g, grad in enumerate(gradovi):
            print("Grad: " + imena_gradova[g] + " (" + str(g) + ")")
            for i in range(broj_eksperimenata):
                print("Eksperiment: " + str(i))
                if abs(rjesenja[h,r,g,i]) < 0.001:
                    #print("Eksperiment: " + str(i))
                    vrijeme_na_pocetku = time.time()
                    population, population_fitness = PomocneFunkcije.makePopulation(heur, population_size, grad, randomness)
                    najbolje_rjesenje = PomocneFunkcije.algorithm(population, population_fitness, population_size, len(grad))
                    vremena[h,r,g,i] = time.time() - vrijeme_na_pocetku
                    rjesenja[h,r,g,i] = int(PomocneFunkcije.evaluate(najbolje_rjesenje))
                    np.save('data', rjesenja)
                    np.save('times', vremena)

def prikaziRezultate():
    for h, heur in enumerate(heuristike):
        print("Heuristika: " + imena_heuristika[h])
        for r, randomness in enumerate(randomnesses):
            for g, grad in enumerate(gradovi):
                average_fitness = 0
                average_time = 0
                for i in range(broj_eksperimenata):
                    average_fitness += rjesenja[h,r,g,i]
                    average_time += vremena[h,r,g,i]
                    
                average_fitness /= broj_eksperimenata
                average_fitness_arr[h,r,g] = average_fitness
                
                average_time /= broj_eksperimenata
                average_times[h,r,g] = average_time
                
                stdev_arr[h,r,g] = np.std(rjesenja[h,r,g])
            info = {'Grad': imena_gradova, 'Avg.': average_fitness_arr[h,r], 'St. dev.': stdev_arr[h,r], 'Avg. time': average_times[h,r]}
            print("Randomness: " + str(randomness*100) + "%")
            print(tabulate(info, headers='keys', tablefmt='fancy_grid'))

prikaziRezultate()